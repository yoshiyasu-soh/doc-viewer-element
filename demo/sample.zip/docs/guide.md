# Guide

A second file inside the archive.

## Usage

Pick files from the Folder panel.
